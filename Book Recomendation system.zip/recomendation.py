# -*- coding: utf-8 -*-
"""
Created on Fri May 22 00:44:11 2020

@author: LENOVO
"""


import pandas as pd
import numpy as np

#book_tag= pd.read_csv('book_tags.csv')
#books=pd.read_csv('books.csv')
ratings=pd.read_csv('ratings.csv')
#to_read=pd.read_csv('to_read.csv')

from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS
from pyspark.sql import Row
from pyspark.ml import Pipeline

#ratings = spark.createDataFrame(ratings)
#(training, test) = ratings.randomSplit([0.8, 0.2])

#(training,test)=transformed.randomSplit([0.8, 0.2])

als = ALS(maxIter=5, regParam=0.01, userCol="user_id", itemCol="book_id", ratingCol="rating",coldStartStrategy="drop") 
model=als.fit(ratings)